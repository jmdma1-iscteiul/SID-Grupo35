import java.util.Date;
import java.text.SimpleDateFormat;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

public class MongoWrite   {
	private MongoClient mongoClient;
	private DB db;
	public MongoWrite(MongoClient mongoClient,DB db) {
		this.mongoClient = mongoClient;
		this.db = db;
	}

	
	public void writeCollectionTemperatura(DBCollection tabela, Object temperatura) {
		BasicDBObject documentoFinal = new BasicDBObject();
		
		documentoFinal.put("Temperatura",temperatura);
		documentoFinal.put("data",new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
		documentoFinal.put("hora",new SimpleDateFormat("HH:mm:ss").format(new Date()));
		documentoFinal.put("migrado","0");
		tabela.insert(documentoFinal);
		}
	public void writeCollectionHumidade(DBCollection tabela,Object humidade) {
		BasicDBObject documentoFinal = new BasicDBObject();
			documentoFinal.put("Humidade",humidade);
			documentoFinal.put("data",new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
			documentoFinal.put("hora",new SimpleDateFormat("HH:mm:ss").format(new Date()));
			documentoFinal.put("migrado","0");
			tabela.insert(documentoFinal);
			
		}
	public void writeCollectionLuminosidade(DBCollection tabela,Object luminosidade) {
		BasicDBObject documentoFinal = new BasicDBObject();
		documentoFinal.put("Luminosidade",luminosidade);
		documentoFinal.put("data",new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
		documentoFinal.put("hora",new SimpleDateFormat("HH:mm:ss").format(new Date()));
		documentoFinal.put("migrado","0");
		tabela.insert(documentoFinal);
	}
	public void writeCollectionMovimento(DBCollection tabela,Object movimento) {
		BasicDBObject documentoFinal = new BasicDBObject();
		//n esquecer alterar
		documentoFinal.put("Movimento","0");
		documentoFinal.put("data",new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
		documentoFinal.put("hora",new SimpleDateFormat("HH:mm:ss").format(new Date()));
		documentoFinal.put("migrado","0");
		tabela.insert(documentoFinal);
	}
	
}
	