import java.sql.SQLException;
import java.util.ArrayList;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class MongoReadTmpHum {
	private Double valorAnterior;
	private Double valorAtual = 0.0;
	private MongoClient mongoClient1;
	private String nomeColecao;
	private DB db;
	private Mysql sql;
	private String tipo;
	private double[] limites;
	private BasicDBObject queryProcura;
	private BasicDBObject queryUpdate = new BasicDBObject();

	@SuppressWarnings("deprecation")
	public MongoReadTmpHum(Mysql msql, String nomeColecao, String tipo) {

		// TODO Auto-generated method stub
		this.mongoClient1 = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
		this.db = mongoClient1.getDB("sid2020");
		this.sql = msql;
		this.nomeColecao = nomeColecao;
		this.tipo = tipo;
		try {
			this.limites = sql.getLimites(tipo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (tipo.equals("Temperatura")) {
			this.valorAnterior = 50.00;
		} else {
			this.valorAnterior = 60.0;
		}
		this.queryProcura = new BasicDBObject("migrado", "0");
		this.queryUpdate.append("$set", new BasicDBObject().append("migrado", "1"));
	}

	public void run() throws SQLException {
		DBCollection table = db.getCollection(nomeColecao);
		DBObject query = new BasicDBObject("migrado", "0");
		DBCursor cursor = table.find(query);
		ArrayList<DBObject> valores = new ArrayList<DBObject>();
		ArrayList<DBObject> valoresErro = new ArrayList<DBObject>();
		while (cursor.hasNext()) {
			// dentro do while
			DBObject Objecto = cursor.next();
			table.update(queryProcura, queryUpdate);
			if (valorValido(Objecto)) {
				valores.add(Objecto);
				try {
					detetarAlerta(Objecto);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				valoresErro.add(Objecto);
			}
		}
		try {
			sql.enviarValores(valores, tipo);
		} catch (NumberFormatException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (valoresErro.size() > 0)
			sql.enviarErros(valoresErro, tipo);
	}

	public boolean valorValido(DBObject objeto) {
		valorAtual = Double.parseDouble(objeto.get(tipo).toString());
		if (valorAtual < valorAnterior + valorAnterior * 0.3 && valorAtual > valorAnterior - valorAnterior * 0.3) {
			this.valorAnterior = valorAtual;
			return true;
		}
		return false;
	}

	public void detetarAlerta(DBObject medicao) throws SQLException {
		double medicaoAtual = Double.parseDouble((medicao.get(tipo).toString()));
		double limiteSuperiorAlertaAmarelo = limites[1] - ((limites[1] - limites[0]) / 4);
		double limiteInferiorAlertaAmarelo = limites[0] + ((limites[1] - limites[0]) / 4);
		if (medicaoAtual >= limites[1]) {
			sql.lancarAlertaVermelho("Alerta Vermelho " + tipo, limites[1], medicaoAtual, tipo);
		}
		if (medicaoAtual <= limites[0]) {
			sql.lancarAlertaVermelho("Alerta Vermelho " + tipo, limites[0], medicaoAtual, tipo);
		}
		if (medicaoAtual >= limiteSuperiorAlertaAmarelo && medicaoAtual < limites[1]) {
			sql.lancarAlertaAmarelo("Alerta Amarelo " + tipo, limites[1], medicaoAtual, tipo);
		}
		if (medicaoAtual <= limiteInferiorAlertaAmarelo && medicaoAtual > limites[0]) {
			sql.lancarAlertaAmarelo("Alerta Amarelo " + tipo, limites[0], medicaoAtual, tipo);
		}

	}

}
