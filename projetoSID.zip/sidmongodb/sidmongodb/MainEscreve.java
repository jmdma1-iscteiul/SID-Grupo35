package sidmongodb;

public class MainEscreve {

	public static void main(String[]args) {
	//	SimulateSensor sm = SimulateSensor();
		
	}
}
