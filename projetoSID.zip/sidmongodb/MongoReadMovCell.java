import java.sql.SQLException;
import java.util.ArrayList;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class MongoReadMovCell {
	// private ArrayList<DBObject> valores = new ArrayList<DBObject>();
	private MongoClient mongoClient1;
	private String nomeColecao;
	private DB db;
	private Mysql sql;
	private String tipo;
	private double[] limites;
	private BasicDBObject queryProcura;
	private BasicDBObject queryUpdate = new BasicDBObject();

	@SuppressWarnings("deprecation")
	public MongoReadMovCell(Mysql msql, String nomeColecao, String tipo) {

		// TODO Auto-generated method stub
		this.mongoClient1 = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));

		this.db = mongoClient1.getDB("sid2020");
		this.sql = msql;
		this.nomeColecao = nomeColecao;
		this.tipo = tipo;
		if (tipo.contains("Luminosidade")) {
			try {
				this.limites = sql.getLimites(tipo);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.queryProcura = new BasicDBObject("migrado", "0");
		this.queryUpdate.append("$set", new BasicDBObject().append("migrado", "1"));
	}

	public void run() throws SQLException {
		DBCollection table = db.getCollection(nomeColecao);
		DBObject query = new BasicDBObject("migrado", "0");
		DBCursor cursor = table.find(query); // falta condicao exportado = 0
		ArrayList<DBObject> valores = new ArrayList<DBObject>();
		while (cursor.hasNext()) {
			DBObject Objecto = cursor.next();
			table.update(queryProcura, queryUpdate);
			valores.add(Objecto);
			detetarAlerta(Objecto);

		}

		try {

			sql.enviarValores(valores, tipo);
		} catch (NumberFormatException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void detetarAlerta(DBObject medicao) throws SQLException {
		if (tipo.contains("Luminosidade")) {
			double medicaoAtual = Double.parseDouble((medicao.get(tipo).toString()));
			if (medicaoAtual > limites[0] && sql.rondasAtivas() == false) {
				sql.lancarAlertaVermelho("Alerta Vermelho " + tipo, limites[0], medicaoAtual, tipo);
			}
		}
		if (tipo.contains("Movimento")) {
			int medicaoAtual = Integer.parseInt((medicao.get(tipo).toString()));
			if (medicaoAtual == 1 && sql.rondasAtivas() == false) {
				sql.lancarAlertaVermelho("Alerta Vermelho " + tipo, 1, medicaoAtual, tipo);
			}

		}
	}

}
