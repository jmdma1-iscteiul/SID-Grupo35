import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.mongodb.DBObject;

public class Mysql {
	private Connection con;
	private Statement st;
	private ResultSet rs, rs1;
	private MongoReadTmpHum readTemperatura;
	private MongoReadTmpHum readHumidade;
	// private MongoReadMovCell readMovimmento;
	private MongoReadMovCell readLuminosidade;

	public Mysql() {
		String database_password = new String();
		String database_user = new String();
		String database_connection = new String();
		database_password = "";
		database_user = "root";
		database_connection = "jdbc:mysql://localhost/sid2020";
		try {
			// Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager
					.getConnection(database_connection + "?user=" + database_user + "&password=" + database_password);
			this.st = con.createStatement();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Erro");
		}
		ligacoesMongo();
	}

	public void start(int periocidade) {
		ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);

		scheduledExecutorService.scheduleWithFixedDelay(new Runnable() {
			@Override
			public void run() {
				sqlStart();
			}
		}, periocidade, periocidade, TimeUnit.SECONDS);
	}

	public void ligacoesMongo() {
		readTemperatura = new MongoReadTmpHum(this, "LeiturasTemperatura", "Temperatura");
		readHumidade = new MongoReadTmpHum(this, "LeiturasHumidade", "Humidade");
		// MongoReadMovCell readMovimento = new MongoReadMovCell(this,
		// "LeiturasMovimento", "Movimento");
		readLuminosidade = new MongoReadMovCell(this, "LeiturasLuminosidade", "Luminosidade");
	}

	public void sqlStart() {
		readTemperatura.run();
		readHumidade.run();
		// readMovimento.run();
		readLuminosidade.run();

	}

	public void enviarValores(ArrayList<DBObject> valores, String tipo) throws SQLException {
		for (int i = 0; i < valores.size(); i++) {
		//	String DataHora = valores.get(i).get("data").toString() + " " + valores.get(i).get("hora");
			// Timestamp ts = Timestamp.valueOf(DataHora);
			String query = "INSERT INTO medicoessensores(ValorMedicao,TipoSensor,DataHoraMedicao) VALUES(" + Double.parseDouble(valores.get(i).get(tipo).toString()) + ", '" + tipo + "',  current_timestamp())";
			st.executeUpdate(query);
		}
	}

	public boolean rondasAtivas() throws SQLException {
		int countRondaPlaneada = 0;
		int countRondaExtra = 0;
		String queryPlaneado = "SELECT * FROM ronda_planeada WHERE isActive = 1";
		rs = st.executeQuery(queryPlaneado);
		while (rs.next())
			countRondaPlaneada++;
		String queryExtra = "SELECT * FROM ronda_extra WHERE isActive = 1";
		rs1 = st.executeQuery(queryExtra);
		while (rs1.next())
			countRondaExtra++;
		if (countRondaExtra + countRondaPlaneada > 0)
			return true;

		return false;
	}

	public double[] getLimitesTemperatura(String tipoSensor) throws SQLException {
		double[] limites = new double[2];
		String querySup = "SELECT Limite" + tipoSensor + "Superior from sistema";
		rs = st.executeQuery(querySup);
		while (rs.next()) {
			limites[1] = Double.parseDouble(rs.getString("Limite" + tipoSensor + "Superior"));
			limites[1] = 25.0;
		}
		String queryInf = "select Limite" + tipoSensor + "Inferior from sistema";
		rs1 = st.executeQuery(queryInf);
		while (rs1.next()) {
			limites[0] = Double.parseDouble(rs1.getString("Limite" + tipoSensor + "Inferior"));
		}
		return limites;
	}

	public void lancarAlertaVermelho(DBObject medicao, String descricao, double limite,
			double valorMedido,String tipo) throws SQLException {

		String query = "insert into alerta(DataHoraMedicao,TipoSensor,ValorMedicao,Limite,Descricao) VALUES(current_timestamp(), '" + tipo + "', " 
				+ valorMedido + ", " + limite +", '" + descricao + "')";
		st.executeUpdate(query);
	}

	public void lancarAlertaAmarelo(DBObject medicao, String descricao, double limite,
			double valorMedido,String tipo) throws SQLException {
		// Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		String query = "insert into alerta(DataHoraMedicao,TipoSensor,ValorMedicao,Limite,Descricao) VALUES(current_timestamp(), '" + tipo + "', "
				+ valorMedido + ", " + limite + ", '" + descricao + "')";
		st.execute(query);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mysql ms = new Mysql();
		ms.start(10);

	}
}
