import java.sql.SQLException;
import java.util.ArrayList;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class MongoReadMovCell {
	// private ArrayList<DBObject> valores = new ArrayList<DBObject>();
	private MongoClient mongoClient1;
	private String nomeColecao;
	private DB db;
	private Mysql sql;
	private String tipo;
	private double[] limites;

	@SuppressWarnings("deprecation")
	public MongoReadMovCell(Mysql msql, String nomeColecao, String tipo) {

		// TODO Auto-generated method stub
		this.mongoClient1 = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));

		this.db = mongoClient1.getDB("sid2020");
		this.sql = msql;
		this.nomeColecao = nomeColecao;
		this.tipo = tipo;
		if (tipo.contains("Luminosidade")) {
			try {
				this.limites = sql.getLimitesTemperatura(tipo);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void run() {
		DBCollection table = db.getCollection(nomeColecao);
		DBObject query = new BasicDBObject("migrado", "0");
		DBCursor cursor = table.find(query); // falta condicao exportado = 0
		ArrayList<DBObject> valores = new ArrayList<DBObject>();

		while (cursor.hasNext()) {
			DBObject Objecto = cursor.next();
			// if (valorValido(Double.parseDouble(Objecto.get(tipo).toString()))) {
			valores.add(Objecto);
			try {
				detetarAlerta(Objecto);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

			try {
				sql.enviarValores(valores, tipo);
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	}

	public void detetarAlerta(DBObject medicao) throws SQLException {
		if (tipo.contains("Luminosidade")) {
			double medicaoAtual = Double.parseDouble((medicao.get(tipo).toString()));
			if (medicaoAtual > limites[0] && sql.rondasAtivas() == false) {
				sql.lancarAlertaVermelho(medicao, "Alerta Vermelho " + tipo, limites[0], medicaoAtual,tipo);
			}
		}
		if (tipo.contains("Movimento")) {
			double medicaoAtual = Double.parseDouble((medicao.get(tipo).toString()));
			if (medicaoAtual == 1 && !sql.rondasAtivas()) {
				sql.lancarAlertaVermelho(medicao, "Alerta Vermelho " + tipo, limites[1], medicaoAtual,tipo);
			}
		}

	}

}
