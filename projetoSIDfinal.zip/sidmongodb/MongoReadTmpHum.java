import java.sql.SQLException;
import java.util.ArrayList;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class MongoReadTmpHum {
	private Double valorAnterior;
	private Double valorAtual = 0.0;
	private MongoClient mongoClient1;
	private String nomeColecao;
	private DB db;
	private Mysql sql;
	private String tipo;
	private double[] limites;
	private BasicDBObject queryProcura;
	private BasicDBObject queryUpdate = new BasicDBObject();
	private ArrayList<DBObject> valoresAlertaSuperior,valoresAlertaInferior,valoresAAInferior,valoresAASuperior;

	@SuppressWarnings("deprecation")
	public MongoReadTmpHum(Mysql msql, String nomeColecao, String tipo) {
		
		/*  Liga��o ao cliente MongoDB e base dados "db" para exporta��o e analise de valores */
		// TODO Auto-generated method stub
		this.mongoClient1 = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
		this.db = mongoClient1.getDB("sid2020");
		this.sql = msql;
		this.nomeColecao = nomeColecao;
		this.tipo = tipo;
		try {
			this.limites = sql.getLimites(tipo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (tipo.equals("Temperatura")) {
			this.valorAnterior = 30.00;
		} else {
			this.valorAnterior = 37.00;
		}
		//query que � usada para procurar os documentos com campo "migrado" a 0
		this.queryProcura = new BasicDBObject("migrado", "0");
		//query que � usada para atualizar o campo "migrado" para 1
		this.queryUpdate.append("$set", new BasicDBObject().append("migrado", "1"));
	}

	/* os valores s�o agrupados, validados e se for cado disso os alertas detetados
	 	A informa��o � entao enviada para o mysql*/
	public void run() throws SQLException {
		// Defeni��o da cole��o que vamos aceder (table), onde o nomeColecao foi fornecido no construtor.
		DBCollection table = db.getCollection(nomeColecao);
		//query ser� o filtro de pesquisa, neste caso queremos documentos que apresentem o campo migrado = 0.
		DBObject query = new BasicDBObject("migrado", "0");
		//cursor ser� a lista exportada de todos os resultados devolvidos com o filtro da "query",
		DBCursor cursor = table.find(query);
		ArrayList<DBObject> valores = new ArrayList<DBObject>();
		ArrayList<DBObject> valoresErro = new ArrayList<DBObject>();
		valoresAlertaSuperior = new ArrayList<DBObject>();
		valoresAlertaInferior = new ArrayList<DBObject>();
		valoresAAInferior = new ArrayList<DBObject>();
		valoresAASuperior = new ArrayList<DBObject>();
		while (cursor.hasNext()) {
			DBObject Objecto = cursor.next();
			//Altera��o nos documentos da cole��o, atualizando "migrado" para "1";
			table.update(queryProcura, queryUpdate);
			if (valorValido(Objecto)) {
				valores.add(Objecto);
				try {
					detetarAlerta(Objecto);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				valoresErro.add(Objecto);
			}
		}
		try {
			sql.enviarValoresTmpHum(valores, tipo);
			if(valoresAlertaSuperior.size() > 0) 
				sql.lancarAlertaVermelho(valoresAlertaSuperior,"Alerta Vermelho " + tipo, limites[1], tipo);
			if(valoresAlertaInferior.size() > 0) 
				sql.lancarAlertaVermelho(valoresAlertaInferior,"Alerta Vermelho " + tipo, limites[0], tipo);
			if(valoresAASuperior.size() > 0) 
				sql.lancarAlertaAmarelo(valoresAASuperior,"Alerta Amarelo " + tipo, limites[1], tipo);
			if(valoresAAInferior.size() > 0) 
				sql.lancarAlertaAmarelo(valoresAAInferior,"Alerta Vermelho " + tipo, limites[0], tipo);
		} catch (NumberFormatException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (valoresErro.size() > 0)
			sql.enviarErros(valoresErro, tipo);
	}

	public boolean valorValido(DBObject objeto) {
		valorAtual = Double.parseDouble(objeto.get(tipo).toString());
		if (valorAtual < valorAnterior + valorAnterior * 0.3 && valorAtual > valorAnterior - valorAnterior * 0.3) {
			this.valorAnterior = valorAtual;
			return true;
		}
		return false;
	}

	public void detetarAlerta(DBObject medicao) throws SQLException {
		double medicaoAtual = Double.parseDouble((medicao.get(tipo).toString()));
		double limiteSuperiorAlertaAmarelo = limites[1] - ((limites[1] - limites[0]) / 4);
		double limiteInferiorAlertaAmarelo = limites[0] + ((limites[1] - limites[0]) / 4);
		if (medicaoAtual >= limites[1]) {
			valoresAlertaSuperior.add(medicao);
			//sql.lancarAlertaVermelho("Alerta Vermelho " + tipo, limites[1], medicaoAtual, tipo);
		}
		if (medicaoAtual <= limites[0]) {
			valoresAlertaInferior.add(medicao);
		//	sql.lancarAlertaVermelho("Alerta Vermelho " + tipo, limites[0], medicaoAtual, tipo);
		}
		if (medicaoAtual >= limiteSuperiorAlertaAmarelo && medicaoAtual < limites[1]) {
			valoresAASuperior.add(medicao);
			//sql.lancarAlertaAmarelo("Alerta Amarelo " + tipo, limites[1], medicaoAtual, tipo);
		}
		if (medicaoAtual <= limiteInferiorAlertaAmarelo && medicaoAtual > limites[0]) {
			valoresAAInferior.add(medicao);
			//sql.lancarAlertaAmarelo("Alerta Amarelo " + tipo, limites[0], medicaoAtual, tipo);
		}

	}

}
