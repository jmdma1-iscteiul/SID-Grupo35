import java.io.FileInputStream;
import java.util.Properties;
import java.util.Random;

import javax.swing.JOptionPane;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.util.JSON;


@SuppressWarnings("deprecation")
public class CloudToMongo implements MqttCallback {
    MqttClient mqttclient;
    static MongoClient mongoClient;
    static DB db;
    static DBCollection mongocolTemperatura,mongocolHumidade,mongocolLuminosidade,mongocolMovimento;
    static String cloud_server = new String();
    static String cloud_topic = new String();
    static String mongo_host = new String();
    static String mongo_database = new String();
    static String mongo_collection = new String();
    static MongoWrite mongoWrite ;
    int i = 0;

    public static void main(String[] args) {

        try {
            Properties p = new Properties();
            p.load(new FileInputStream("cloudToMongo.ini"));
            cloud_server = p.getProperty("cloud_server");
            cloud_topic = p.getProperty("cloud_topic");
            mongo_host = p.getProperty("mongo_host");
            mongo_database = p.getProperty("mongo_database");
        } catch (Exception e) {

            System.out.println("Error reading CloudToMongo.ini file " + e);
            JOptionPane.showMessageDialog(null, "The CloudToMongo.inifile wasn't found.", "CloudToMongo", JOptionPane.ERROR_MESSAGE);
        }
        new CloudToMongo().connecCloud();
        new CloudToMongo().connectMongo();
    }

    public void connecCloud() {
		int i;
        try {
			i = new Random().nextInt(100000);
            mqttclient = new MqttClient(cloud_server, "CloudToMongo_"+String.valueOf(i)+"_"+cloud_topic);
            mqttclient.connect();
            mqttclient.setCallback(this);
            mqttclient.subscribe(cloud_topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    /*Aqui � estabelecido a liga��o ao cliente � base dados mongo "db"(sid2020) e
      defenidas as cole��es presentes na bd a serem usadas, */
    public void connectMongo() {
		mongoClient = new MongoClient(new MongoClientURI(mongo_host));
		db = mongoClient.getDB(mongo_database);
        mongocolTemperatura = db.getCollection("LeiturasTemperatura");
        mongocolHumidade = db.getCollection("LeiturasHumidade");
        mongocolLuminosidade = db.getCollection("LeiturasLuminosidade");
        mongocolMovimento = db.getCollection("LeiturasMovimento");
        
        mongoWrite = new MongoWrite(mongoClient,db);
    }
    @Override
    public void messageArrived(String topic, MqttMessage c)
            throws Exception {
        try {
        	i++;
                DBObject document_json;
                document_json = (DBObject) JSON.parse(clean(c.toString()));
                
                /* Aqui � introduzido os valores que chegam do sensor para serem 
                 escritos na base dados Mongo, apenas se existirem os seus campos na mensagem do sensor */   
                if(document_json.toString().contains("tmp"))
                	mongoWrite.writeCollection(mongocolTemperatura,document_json.get("tmp"),"Temperatura");
                if(document_json.toString().contains("hum"))
                	mongoWrite.writeCollection(mongocolHumidade,document_json.get("hum"),"Humidade");
                if(document_json.toString().contains("cell")) 
            	   mongoWrite.writeCollection(mongocolLuminosidade, document_json.get("cell"),"Luminosidade");
                if(document_json.toString().contains("mov"))
                	mongoWrite.writeCollection(mongocolMovimento,/*document_json.get("mov")*/ "1","Movimento");
            
               System.out.println(i);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    }
  
    public String clean(String message) {
		return (message.replaceAll("\"\"", "\""));
        
    }	

}