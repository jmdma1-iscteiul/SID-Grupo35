import java.util.Date;
import java.text.SimpleDateFormat;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

public class MongoWrite   {
	private MongoClient mongoClient;
	private DB db;
	public MongoWrite(MongoClient mongoClient,DB db) {
		this.mongoClient = mongoClient;
		this.db = db;
	}
	/* Informa��o que � introduzida na base dados Mongo
	   � introduzido no documento o valor das medi��es (Temperatura,Humidade,Luminosidade,Movimento identificado pelo tipo),
	   um campo migrado = 0 e  a data e  a hora em que est� a ser escrito na colecao.
	   O Valor da medi��o � identificado pelo objeto valor.
	   tabela varia para cada caso que corresponde a cada cole��o */
	
	public void writeCollection(DBCollection tabela, Object valor,String tipo) {
		BasicDBObject documentoFinal = new BasicDBObject();	
		documentoFinal.put(tipo,valor);
		documentoFinal.put("data",new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
		documentoFinal.put("hora",new SimpleDateFormat("HH:mm:ss").format(new Date()));
		documentoFinal.put("migrado","0");
		tabela.insert(documentoFinal);
		}

}
	